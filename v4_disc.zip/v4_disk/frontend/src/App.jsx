import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { CssBaseline, ThemeProvider } from "@mui/material";

import AiMenuDialog from "./components/AiMenuDialog";
import AiPromptsDialog from "./components/AiPromptsDialog";
import AiReportDialog from "./components/AiReportDialog";
import TaskFactsDialog from "./components/TaskFactsDialog";
import GenerationQueueDrawer from "./components/GenerationQueueDrawer";
import InterfaceMenuDialog from "./components/InterfaceMenuDialog";
import PageModalDialog from "./components/PageModalDialog";
import {
  cancelGenerationJob,
  clearStoredTokens,
  fetchGenerationJobs,
  fetchInterfaceBackground,
  fetchInterfaceSettings,
  fetchMe,
  fetchProverkaAiReport,
  fetchProverkaMonitoring,
  getStoredTokens,
  login,
  logout,
  requestPasswordReset,
  resetPasswordWithToken,
  runProverkaAiReport,
  setStoredTokens,
  verifyMfaLogin,
} from "./api";
import { DEFAULT_THEME, isValidTheme } from "./constants/themes";
import DashboardPage from "./pages/DashboardPage";
import LogsPage from "./pages/LogsPage";
import SchedulePage from "./pages/SchedulePage";
import UsersPage from "./pages/UsersPage";
import AppShell from "./shell/AppShell";
import LoginPage from "./shell/LoginPage";
import { createAppTheme } from "./theme";
import logoUrl from "./assets/logo.png";

function todayIso() {
  return new Date().toISOString().slice(0, 10);
}

function formatQueueTime(iso) {
  if (!iso) return "";
  try {
    return new Date(iso).toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });
  } catch {
    return "";
  }
}

/** Стабильный отпечаток очереди: без изменений setState не вызываем → нет лишних ререндеров. */
function queueFingerprint(items) {
  if (!items?.length) return "";
  return items
    .map((j) => {
      const done = j.completed_report_ids?.length ?? 0;
      const failed = j.failed_report_ids?.length ?? j.failed?.length ?? 0;
      return `${j.id}:${j.status}:${j.updated_at || ""}:${done}:${failed}`;
    })
    .join("|");
}

function stableSetIfChanged(setter, next, fingerprintFn) {
  setter((prev) => {
    if (fingerprintFn(prev) === fingerprintFn(next)) return prev;
    return next;
  });
}

export default function App() {
  const interfaceReqRef = useRef(0);
  const backgroundVersionRef = useRef(null);
  const [theme, setTheme] = useState(DEFAULT_THEME);
  const [customBackground, setCustomBackground] = useState("");
  const [interfaceSettingsLoaded, setInterfaceSettingsLoaded] = useState(false);
  const [user, setUser] = useState(null);
  const [authChecked, setAuthChecked] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mfaCode, setMfaCode] = useState("");
  const [mfaRequired, setMfaRequired] = useState(false);
  const [mfaPendingToken, setMfaPendingToken] = useState("");
  const [authError, setAuthError] = useState("");
  const [authInfo, setAuthInfo] = useState("");
  const [authView, setAuthView] = useState(() =>
    new URLSearchParams(window.location.search).get("reset_token") ? "reset" : "login",
  );
  const [resetToken, setResetToken] = useState(
    () => new URLSearchParams(window.location.search).get("reset_token") || "",
  );
  const [resetPassword, setResetPassword] = useState("");
  const [resetConfirm, setResetConfirm] = useState("");
  const [authBusy, setAuthBusy] = useState(false);
  const [activeNav, setActiveNav] = useState("dashboard");
  const [generationQueue, setGenerationQueue] = useState([]);
  const [queueDrawerOpen, setQueueDrawerOpen] = useState(false);
  const [summaryDate, setSummaryDate] = useState(todayIso);
  const [monitoring, setMonitoring] = useState(null);
  const [aiReportOpen, setAiReportOpen] = useState(false);
  const [aiPromptsOpen, setAiPromptsOpen] = useState(false);
  const [aiMenuOpen, setAiMenuOpen] = useState(false);
  const [taskFactsOpen, setTaskFactsOpen] = useState(false);
  const [taskFactsJobId, setTaskFactsJobId] = useState("");
  const [interfaceOpen, setInterfaceOpen] = useState(false);
  const [aiReport, setAiReport] = useState(null);
  const [aiReportLoading, setAiReportLoading] = useState(false);
  const [aiReportError, setAiReportError] = useState("");
  const [aiRefreshing, setAiRefreshing] = useState(false);
  const [logsFocus, setLogsFocus] = useState(null);
  const [logsModalOpen, setLogsModalOpen] = useState(false);
  const [scheduleModalOpen, setScheduleModalOpen] = useState(false);
  const [usersModalOpen, setUsersModalOpen] = useState(false);
  const [dashboardHeaderTools, setDashboardHeaderTools] = useState(null);

  // Как в старой версии ~5 с при активных задачах; idle редко. AI/мониторинг отдельно и реже.
  const POLL_IDLE_MS = 30_000;
  const POLL_ACTIVE_MS = 5_000;
  const POLL_AI_MS = 20_000;

  const muiTheme = useMemo(() => createAppTheme(theme), [theme]);

  useEffect(() => {
    let favicon = document.querySelector("link[rel='icon']");
    if (!favicon) {
      favicon = document.createElement("link");
      favicon.setAttribute("rel", "icon");
      document.head.appendChild(favicon);
    }
    favicon.setAttribute("href", logoUrl);
  }, []);

  const isDeveloper = user?.role === "developer";
  const openTaskFacts = useCallback((jobId) => {
    setTaskFactsJobId(jobId || "");
    setTaskFactsOpen(true);
  }, []);
  const canGenerate =
    user?.role === "developer" || user?.role === "admin" || user?.role === "user";

  // Сброс интерфейса к умолчанию (выход, смена пользователя, ошибка загрузки).
  // Увеличение счётчика делает недействительными все уже запущенные загрузки.
  const resetInterface = useCallback(() => {
    interfaceReqRef.current += 1;
    backgroundVersionRef.current = null;
    setTheme(DEFAULT_THEME);
    setCustomBackground("");
  }, []);

  const applyInterfaceSettings = useCallback(async (settings) => {
    const reqId = ++interfaceReqRef.current;
    const nextTheme = isValidTheme(settings?.theme) ? settings.theme : DEFAULT_THEME;
    setTheme(nextTheme);
    if (!settings?.has_custom_background) {
      backgroundVersionRef.current = null;
      setCustomBackground("");
      return;
    }
    const version = settings.background_version || 0;
    if (backgroundVersionRef.current === version) {
      // Фон не менялся (например, сменили только тему) — не скачиваем заново.
      return;
    }
    try {
      const blobUrl = await fetchInterfaceBackground(version);
      if (reqId !== interfaceReqRef.current) {
        // За время загрузки пользователь сменился или пришли новые настройки.
        URL.revokeObjectURL(blobUrl);
        return;
      }
      backgroundVersionRef.current = version;
      setCustomBackground(blobUrl);
    } catch {
      if (reqId === interfaceReqRef.current) {
        backgroundVersionRef.current = null;
        setCustomBackground("");
      }
    }
  }, []);

  const loadInterfaceSettings = useCallback(async () => {
    if (!getStoredTokens().access) {
      resetInterface();
      setInterfaceSettingsLoaded(true);
      return;
    }
    const startedAt = interfaceReqRef.current;
    try {
      const settings = await fetchInterfaceSettings();
      if (startedAt !== interfaceReqRef.current) return; // пользователь сменился
      await applyInterfaceSettings(settings);
    } catch {
      if (startedAt !== interfaceReqRef.current) return;
      resetInterface();
    }
    setInterfaceSettingsLoaded(true);
  }, [applyInterfaceSettings, resetInterface]);

  useEffect(() => {
    if (!authChecked) return;
    // Другой пользователь — начинаем с чистого интерфейса, чужой фон не показываем.
    resetInterface();
    setInterfaceSettingsLoaded(false);
    loadInterfaceSettings();
  }, [authChecked, user?.id, loadInterfaceSettings, resetInterface]);

  // Blob-URL фона освобождается, когда он заменён новым или компонент удалён:
  // старый адрес живёт, пока новый не отрисован (без «мигания»).
  useEffect(() => {
    if (!customBackground) return undefined;
    return () => URL.revokeObjectURL(customBackground);
  }, [customBackground]);

  useEffect(() => {
    document.documentElement.dataset.diskTheme = theme;
  }, [theme]);

  const loadUser = useCallback(async () => {
    const { access } = getStoredTokens();
    if (!access) {
      setUser(null);
      setAuthChecked(true);
      return;
    }
    try {
      const me = await fetchMe();
      setUser(me);
    } catch {
      clearStoredTokens();
      setUser(null);
    } finally {
      setAuthChecked(true);
    }
  }, []);

  const loadGenerationQueue = useCallback(async () => {
    if (!canGenerate) {
      setGenerationQueue((prev) => (prev.length ? [] : prev));
      return;
    }
    try {
      const data = await fetchGenerationJobs();
      const items = data.items || [];
      stableSetIfChanged(setGenerationQueue, items, queueFingerprint);
    } catch {
      setGenerationQueue((prev) => (prev.length ? [] : prev));
    }
  }, [canGenerate]);

  const handleCancelGenerationJob = useCallback(
    async (jobId, reportIds = null) => {
      await cancelGenerationJob(jobId, reportIds);
      await loadGenerationQueue();
    },
    [loadGenerationQueue]
  );

  useEffect(() => {
    loadUser();
  }, [loadUser]);

  const hasActiveGenerationJobs = useMemo(
    () =>
      generationQueue.some((job) => job.status === "pending" || job.status === "running"),
    [generationQueue]
  );

  useEffect(() => {
    if (!user) return undefined;
    loadGenerationQueue();
    const pollMs = hasActiveGenerationJobs ? POLL_ACTIVE_MS : POLL_IDLE_MS;
    const id = setInterval(loadGenerationQueue, pollMs);
    return () => clearInterval(id);
  }, [user, loadGenerationQueue, hasActiveGenerationJobs, POLL_ACTIVE_MS, POLL_IDLE_MS]);

  const loadMonitoring = useCallback(async () => {
    if (!isDeveloper) return;
    try {
      const data = await fetchProverkaMonitoring(summaryDate);
      setMonitoring((prev) => {
        const prevKey = JSON.stringify(prev);
        const nextKey = JSON.stringify(data);
        return prevKey === nextKey ? prev : data;
      });
    } catch {
      setMonitoring((prev) => (prev == null ? prev : null));
    }
  }, [isDeveloper, summaryDate]);

  const loadAiReport = useCallback(async () => {
    if (!isDeveloper) return;
    try {
      const data = await fetchProverkaAiReport(summaryDate);
      setAiReport((prev) => {
        const prevKey = `${prev?.ai_status}|${prev?.ai_violation_count}|${prev?.updated_at || ""}`;
        const nextKey = `${data?.ai_status}|${data?.ai_violation_count}|${data?.updated_at || ""}`;
        return prevKey === nextKey ? prev : data;
      });
    } catch {
      setAiReport((prev) => (prev == null ? prev : null));
    }
  }, [isDeveloper, summaryDate]);

  useEffect(() => {
    if (!user || !isDeveloper) return undefined;
    loadMonitoring();
    loadAiReport();
    // AI/мониторинг не гоняем каждые 2–5 с вместе с очередью — достаточно реже.
    const id = setInterval(() => {
      loadMonitoring();
      loadAiReport();
    }, POLL_AI_MS);
    return () => clearInterval(id);
  }, [user, isDeveloper, summaryDate, loadMonitoring, loadAiReport, POLL_AI_MS]);

  useEffect(() => {
    if (!isDeveloper) return;
    const recentDone = generationQueue.some(
      (j) =>
        j.status === "completed" &&
        j.updated_at &&
        Date.now() - new Date(j.updated_at).getTime() < 60_000
    );
    if (recentDone) loadMonitoring();
  }, [generationQueue, isDeveloper, loadMonitoring]);

  const aiStatus = aiReport?.ai_status || "none";
  const aiViolationCount = aiReport?.ai_violation_count ?? 0;
  const queueLabel = useMemo(() => {
    const active = generationQueue.filter(
      (j) => j.status === "pending" || j.status === "running"
    );
    if (!active.length) return "Очередь";
    const latest = [...active].sort(
      (a, b) => new Date(b.created_at || 0) - new Date(a.created_at || 0)
    )[0];
    const time = formatQueueTime(latest?.created_at);
    if (time) return `Очередь · ${time}`;
    return `Очередь · ${active.length}`;
  }, [generationQueue]);

  const handleAiReportClick = useCallback(async () => {
    setAiReportError("");
    setAiReportLoading(true);
    setAiReportOpen(true);
    try {
      const data = await fetchProverkaAiReport(summaryDate);
      setAiReport(data);
    } catch (e) {
      setAiReportError(String(e.message || e));
    } finally {
      setAiReportLoading(false);
    }
  }, [summaryDate]);

  const handleAiReportRefresh = useCallback(async () => {
    setAiRefreshing(true);
    setAiReportError("");
    try {
      await runProverkaAiReport(summaryDate);
      setTimeout(async () => {
        try {
          const data = await fetchProverkaAiReport(summaryDate);
          setAiReport(data);
        } catch (e) {
          setAiReportError(String(e.message || e));
        } finally {
          setAiRefreshing(false);
        }
      }, 3000);
    } catch (e) {
      setAiReportError(String(e.message || e));
      setAiRefreshing(false);
    }
  }, [summaryDate]);

  const handleProverkaComplete = useCallback(() => {
    loadMonitoring();
    loadAiReport();
  }, [loadMonitoring, loadAiReport]);

  const handleGenerationQueued = useCallback(() => {
    loadGenerationQueue();
    setQueueDrawerOpen(true);
  }, [loadGenerationQueue]);

  const handleOpenLogs = useCallback((focus) => {
    setLogsFocus(focus);
    setLogsModalOpen(true);
  }, []);

  const handleAiReportLoad = useCallback((data) => {
    if (data?.error) {
      setAiReportError(data.error);
    } else {
      setAiReport(data);
      setAiReportError("");
    }
  }, []);

  const handleQueueOpen = useCallback(() => setQueueDrawerOpen(true), []);
  const handleQueueClose = useCallback(() => setQueueDrawerOpen(false), []);
  const handleInterfaceOpen = useCallback(() => setInterfaceOpen(true), []);
  const handleInterfaceClose = useCallback(() => setInterfaceOpen(false), []);
  const handleAiMenuOpen = useCallback(() => setAiMenuOpen(true), []);
  const handleAiMenuClose = useCallback(() => setAiMenuOpen(false), []);
  const handleAiPromptsOpen = useCallback(() => setAiPromptsOpen(true), []);
  const handleOpenTaskFactsFromMenu = useCallback(() => openTaskFacts(), [openTaskFacts]);
  const handleLogsFocusConsumed = useCallback(() => setLogsFocus(null), []);

  const navActiveId = logsModalOpen
    ? "logs"
    : scheduleModalOpen
      ? "schedule"
      : usersModalOpen
        ? "users"
        : activeNav;

  const handleNavChange = useCallback((id) => {
    if (id === "users") {
      setUsersModalOpen(true);
      return;
    }
    if (id === "logs") {
      setLogsModalOpen(true);
      return;
    }
    if (id === "schedule") {
      setScheduleModalOpen(true);
      return;
    }
    setActiveNav(id);
  }, []);

  const nav = useMemo(() => {
    const items = [];
    if (user) {
      items.push({ id: "users", label: "Пользователи" });
    }
    items.push({ id: "dashboard", label: "Сводки" });
    if (canGenerate) {
      items.push({ id: "logs", label: "Логи" });
    }
    if (user?.role === "developer" || user?.role === "admin") {
      items.push({ id: "schedule", label: "Расписание" });
    }
    return items;
  }, [user, isDeveloper, canGenerate]);

  function clearResetTokenFromUrl() {
    const url = new URL(window.location.href);
    url.searchParams.delete("reset_token");
    window.history.replaceState({}, "", `${url.pathname}${url.search}${url.hash}`);
    setResetToken("");
  }

  function backToLogin() {
    clearResetTokenFromUrl();
    setAuthView("login");
    setAuthError("");
    setResetPassword("");
    setResetConfirm("");
  }

  async function handleAuthSubmit(e) {
    e.preventDefault();
    setAuthError("");
    if (authView === "forgot") {
      setAuthBusy(true);
      setAuthInfo("");
      try {
        const res = await requestPasswordReset(email.trim());
        setAuthInfo(res?.detail || "Если такой email есть в системе, мы отправили письмо со ссылкой.");
        setAuthView("login");
      } catch (err) {
        setAuthError(String(err.message || err));
      } finally {
        setAuthBusy(false);
      }
      return;
    }
    if (authView === "reset") {
      if (resetPassword.length < 8) {
        setAuthError("Новый пароль — минимум 8 символов");
        return;
      }
      if (resetPassword !== resetConfirm) {
        setAuthError("Новый пароль и подтверждение не совпадают");
        return;
      }
      setAuthBusy(true);
      setAuthInfo("");
      try {
        const res = await resetPasswordWithToken(resetToken, resetPassword);
        clearResetTokenFromUrl();
        setResetPassword("");
        setResetConfirm("");
        setPassword("");
        await logout();
        setUser(null);
        setAuthView("login");
        setAuthInfo(res?.detail || "Пароль обновлён. Войдите с новым паролем.");
      } catch (err) {
        setAuthError(String(err.message || err));
      } finally {
        setAuthBusy(false);
      }
      return;
    }
    setAuthBusy(true);
    setAuthInfo("");
    try {
      if (mfaRequired) {
        const pair = await verifyMfaLogin(mfaPendingToken, mfaCode);
        setStoredTokens(pair.access_token, pair.refresh_token);
        setMfaRequired(false);
        setMfaPendingToken("");
        setMfaCode("");
      } else {
        const res = await login(email, password);
        if (res.mfa_required) {
          setMfaRequired(true);
          setMfaPendingToken(res.mfa_pending_token);
          return;
        }
        setStoredTokens(res.access_token, res.refresh_token);
      }
      await loadUser();
    } catch (err) {
      setAuthError(String(err.message || err));
    } finally {
      setAuthBusy(false);
    }
  }

  async function handlePasswordChanged() {
    await handleLogout();
    setAuthInfo("Пароль изменён. Войдите с новым паролем.");
  }

  async function handleLogout() {
    await logout();
    // Всё, что относится к вышедшему пользователю, сбрасываем сразу,
    // чтобы страница входа и следующий пользователь не увидели чужие данные.
    resetInterface();
    setUser(null);
    setActiveNav("dashboard");
    setGenerationQueue([]);
    setMonitoring(null);
    setAiReport(null);
    setAiReportError("");
    setAiReportOpen(false);
    setAiPromptsOpen(false);
    setAiMenuOpen(false);
    setInterfaceOpen(false);
    setLogsFocus(null);
    setLogsModalOpen(false);
    setScheduleModalOpen(false);
    setUsersModalOpen(false);
    setQueueDrawerOpen(false);
    setDashboardHeaderTools(null);
    setEmail("");
    setPassword("");
    setMfaCode("");
    setMfaRequired(false);
    setMfaPendingToken("");
    setAuthError("");
  }

  if (!authChecked || !interfaceSettingsLoaded) {
    return null;
  }

  if (!user || authView === "reset") {
    return (
      <ThemeProvider theme={muiTheme}>
        <CssBaseline />
        <LoginPage
          theme={theme}
          customBackground={customBackground}
          view={authView}
          email={email}
          password={password}
          mfaCode={mfaCode}
          mfaRequired={mfaRequired}
          error={authError}
          info={authInfo}
          busy={authBusy}
          resetPassword={resetPassword}
          resetConfirm={resetConfirm}
          onEmailChange={setEmail}
          onPasswordChange={setPassword}
          onMfaCodeChange={setMfaCode}
          onResetPasswordChange={setResetPassword}
          onResetConfirmChange={setResetConfirm}
          onSubmit={handleAuthSubmit}
          onForgot={() => {
            setAuthView("forgot");
            setAuthError("");
            setAuthInfo("");
          }}
          onBackToLogin={backToLogin}
        />
      </ThemeProvider>
    );
  }

  return (
    <ThemeProvider theme={muiTheme}>
      <CssBaseline />
      <AppShell
        theme={theme}
        customBackground={customBackground}
        user={user}
        onLogout={handleLogout}
        onPasswordChanged={handlePasswordChanged}
        nav={nav}
        activeNav={activeNav}
        navActiveId={navActiveId}
        onNavChange={handleNavChange}
        queueLabel={queueLabel}
        onQueueOpen={handleQueueOpen}
        showQueueButton={canGenerate}
        showAiButton={isDeveloper}
        onInterfaceOpen={handleInterfaceOpen}
        onAiOpen={handleAiMenuOpen}
        aiStatus={aiStatus}
        aiViolationCount={aiViolationCount}
        secondaryToolbar={navActiveId === "dashboard" ? dashboardHeaderTools : null}
      >
        <DashboardPage
          user={user}
          generationQueue={generationQueue}
          summaryDate={summaryDate}
          onSummaryDateChange={setSummaryDate}
          onHeaderToolsChange={setDashboardHeaderTools}
          onProverkaComplete={handleProverkaComplete}
          onGenerationQueued={handleGenerationQueued}
          onOpenLogs={handleOpenLogs}
          onOpenTaskFacts={isDeveloper ? openTaskFacts : undefined}
        />
      </AppShell>
      <GenerationQueueDrawer
        open={queueDrawerOpen && canGenerate}
        onClose={handleQueueClose}
        jobs={generationQueue}
        onCancelJob={handleCancelGenerationJob}
      />
      {interfaceOpen && (
        <InterfaceMenuDialog
          open={interfaceOpen}
          onClose={handleInterfaceClose}
          theme={theme}
          onThemeChange={setTheme}
          customBackground={customBackground}
          onSettingsSaved={applyInterfaceSettings}
        />
      )}
      {aiMenuOpen && (
        <AiMenuDialog
          open={aiMenuOpen}
          onClose={handleAiMenuClose}
          onOpenReport={handleAiReportClick}
          onOpenPrompts={handleAiPromptsOpen}
          onOpenTaskFacts={handleOpenTaskFactsFromMenu}
          isDeveloper={isDeveloper}
          summaryDate={summaryDate}
        />
      )}
      {user && usersModalOpen && (
        <PageModalDialog
          open={usersModalOpen}
          onClose={() => setUsersModalOpen(false)}
          title="Пользователи"
        >
          <UsersPage
            currentUserId={user.id}
            currentUser={user}
            manageAll={isDeveloper}
            embedded
            onPasswordChanged={handlePasswordChanged}
          />
        </PageModalDialog>
      )}
      {canGenerate && logsModalOpen && (
        <PageModalDialog
          open={logsModalOpen}
          onClose={() => setLogsModalOpen(false)}
          title="Логи"
        >
          <LogsPage
            focus={logsFocus}
            onFocusConsumed={handleLogsFocusConsumed}
            canViewUserEvents={isDeveloper}
          />
        </PageModalDialog>
      )}
      {canGenerate && (user?.role === "developer" || user?.role === "admin") && scheduleModalOpen && (
        <PageModalDialog
          open={scheduleModalOpen}
          onClose={() => setScheduleModalOpen(false)}
          title="Расписание"
        >
          <SchedulePage />
        </PageModalDialog>
      )}
      {aiReportOpen && isDeveloper && (
        <AiReportDialog
          open={aiReportOpen}
          onClose={() => setAiReportOpen(false)}
          summaryDate={summaryDate}
          aiData={aiReport}
          loading={aiReportLoading}
          error={aiReportError}
          onRefresh={handleAiReportRefresh}
          refreshing={aiRefreshing}
          onLoadReport={handleAiReportLoad}
        />
      )}
      {aiPromptsOpen && isDeveloper && (
        <AiPromptsDialog
          open={aiPromptsOpen}
          onClose={() => setAiPromptsOpen(false)}
        />
      )}
      {taskFactsOpen && isDeveloper && (
        <TaskFactsDialog
          open={taskFactsOpen}
          onClose={() => setTaskFactsOpen(false)}
          summaryDate={summaryDate}
          initialJobId={taskFactsJobId}
        />
      )}
    </ThemeProvider>
  );
}
